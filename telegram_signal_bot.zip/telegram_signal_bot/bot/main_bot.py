import telegram
import asyncio
import json
import os
import time
from datetime import datetime, time as dt_time
import logging
from signals import generate_signal, format_signal_message
# Configuração básica de logging
logging.basicConfig(
 format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
 level=logging.INFO
)
logger = logging.getLogger(__name__)
CONFIG_FILE = '../dashboard/config.json' # Caminho relativo para o config.json
# Dicionário para rastrear sinais enviados por sessão (dia_semana,
hora_inicio_sessao): contagem
session_signal_counts = {}
def load_config():
 """Carrega as configurações do arquivo JSON."""
 if not os.path.exists(CONFIG_FILE):
 logger.warning(f"Arquivo de configuração '{CONFIG_FILE}' não encontrado. O
bot não enviará sinais até que seja criado.")
 return None
 try:
 with open(CONFIG_FILE, 'r') as f:
 config = json.load(f)
 # Validação básica
 if not all(k in config for k in ['telegram_token',
'telegram_channel_id', 'schedule', 'signals_per_session']):
 logger.error("Arquivo de configuração inválido ou incompleto.")
 return None
 if not isinstance(config['signals_per_session'], int) or
config['signals_per_session'] <= 0:
 logger.error("'signals_per_session' deve ser um inteiro positivo.")
 return None
 return config
 except json.JSONDecodeError:
 logger.error(f"Erro ao decodificar o JSON em '{CONFIG_FILE}'.")
 return None
 except Exception as e:
 logger.error(f"Erro ao carregar configuração: {e}")
 return None
def is_within_time_slot(current_time, time_slot_str):
 """Verifica se a hora atual está dentro de um slot de tempo (ex:
'09:00-10:00')."""
 try:
 start_str, end_str = time_slot_str.split('-')
 start_time = datetime.strptime(start_str, '%H:%M').time()
 # O fim do slot é exclusivo, então consideramos até o último minuto do slot
 end_hour, end_minute = map(int, end_str.split(':'))
 if end_minute == 0:
 end_time = dt_time(end_hour - 1, 59, 59) if end_hour > 0 else
dt_time(23, 59, 59)
 else:
 # Se o slot termina em HH:MM (MM != 00), vai até HH:MM-1
 # Ex: 15:30 -> vai até 15:29:59. Mas como a verificação é a cada
minuto,
 # podemos simplificar e checar se current_time < end_time
 end_time = datetime.strptime(end_str, '%H:%M').time()
 # Lógica ajustada para incluir o início e excluir o fim exato do próximo
bloco
 # Ex: 09:00-10:00 -> Válido de 09:00:00 até 09:59:59
 end_time_exclusive = datetime.strptime(end_str, '%H:%M').time()
 return start_time <= current_time < end_time_exclusive
 except ValueError:
 logger.error(f"Formato de slot de tempo inválido: {time_slot_str}")
 return False
async def main():
 """Função principal do bot."""
 logger.info("Iniciando o bot de sinais...")
 last_checked_day = -1 # Para resetar contadores diários
 while True:
 config = load_config()
 if not config:
 logger.info("Aguardando arquivo de configuração válido...")
 await asyncio.sleep(60) # Espera 1 minuto antes de tentar novamente
 continue
 bot_token = config['telegram_token']
 channel_id = config['telegram_channel_id']
 schedule = config['schedule']
 signals_per_session_limit = config['signals_per_session']
 try:
 bot = telegram.Bot(token=bot_token)
 logger.info("Bot conectado ao Telegram.")
 now = datetime.now()
 current_day_name = now.strftime('%A') # Ex: 'Monday'
 current_time = now.time()
 # Resetar contadores se o dia mudou
 if now.day != last_checked_day:
 logger.info(f"Novo dia ({now.day}), resetando contadores de
sessão.")
 session_signal_counts.clear()
 last_checked_day = now.day
 if current_day_name in schedule:
 active_slots = schedule[current_day_name]
 for slot in active_slots:
 if is_within_time_slot(current_time, slot):
 session_key = (current_day_name, slot)
 current_count = session_signal_counts.get(session_key, 0)
 if current_count < signals_per_session_limit:
 logger.info(f"Dentro do slot ativo '{slot}' para
{current_day_name}. Enviando sinal (Contagem:
{current_count}/{signals_per_session_limit}).")
 pair, direction = generate_signal()
 entry_time_str = now.strftime('%H:%M')
 message = format_signal_message(pair, direction,
entry_time_str)
 try:
 await bot.send_message(chat_id=channel_id,
text=message)
 logger.info(f"Sinal enviado para {channel_id}:
{pair} {direction}")
 session_signal_counts[session_key] = current_count +
1
 except telegram.error.TelegramError as e:
 logger.error(f"Erro ao enviar mensagem para o
Telegram: {e}")
 # Considerar não incrementar a contagem se falhar?
 except Exception as e:
 logger.error(f"Erro inesperado ao enviar mensagem:
{e}")
 # Esperar um pouco antes do próximo sinal para não
floodar (opcional)
 # await asyncio.sleep(5)
 else:
 # logger.info(f"Limite de sinais para a sessão
{session_key} atingido.")
 pass # Apenas não envia mais nesta sessão
 # Importante: sair do loop de slots após encontrar o slot
ativo e decidir enviar/não enviar
 # para evitar enviar múltiplos sinais no mesmo minuto se
houver slots sobrepostos (não deveria haver)
 break # Sai do loop 'for slot in active_slots:'
 except telegram.error.InvalidToken:
 logger.error("Token do Telegram inválido. Verifique o arquivo de
configuração.")
 # Espera mais tempo antes de tentar reconectar com token inválido
 await asyncio.sleep(300)
 except Exception as e:
 logger.error(f"Erro inesperado no loop principal: {e}")
 # Espera um pouco antes de tentar novamente em caso de outros erros
 await asyncio.sleep(60)
 # Espera 60 segundos antes da próxima verificação
 await asyncio.sleep(60)
if __name__ == '__main__':
 asyncio.run(main())