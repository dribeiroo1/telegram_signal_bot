import random
regular_pairs = [
 "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCHF", "USDCAD", "NZDUSD",
 "EURGBP", "EURJPY", "GBPJPY", "GBPAUD", "AUDJPY", "CHFJPY", "CADCHF",
 "CADJPY", "EURAUD", "GBPCAD", "EURCHF", "AUDCAD", "AUDNZD",
 "AUDCHF", "EURSGD", "EURCAD", "USDSGD", "USDZAR", "USDTRY", "USDBRL"
]
otc_pairs = [
 "EURUSD-OTC", "EURGBP-OTC", "USDCHF-OTC", "EURJPY-OTC", "NZDUSD-OTC",
 "GBPUSD-OTC", "AUDCAD-OTC", "AUDUSD-OTC", "USDJPY-OTC", "GBPJPY-OTC",
 "USDCAD-OTC", "CADCHF-OTC", "GBPCHF-OTC", "AUDCHF-OTC", "GBPAUD-OTC"
]
all_pairs = regular_pairs + otc_pairs
def generate_signal():
 """Gera um sinal aleatório (par, direção)."""
 pair = random.choice(all_pairs)
 direction = random.choice(["COMPRA", "VENDA"])
 return pair, direction
def format_signal_message(pair, direction, entry_time_str):
 """Formata a mensagem do sinal para envio no Telegram."""
 indicator = "🟢" if direction == "COMPRA" else "🔴"
 message = (
 f"📈 ATIVO: {pair}\n"
 f"⏰ EXPIRAÇÃO: M5\n"
 f"👍 ENTRADA: {entry_time_str}\n"
 f"📊 Ordem: {indicator} {direction}"
 )
 return message