import sys
import os
import json
from flask import Flask, render_template, request, redirect, url_for, flash
# Garantir que o diretório pai (onde está o config.json) seja acessível
# Isso não é estritamente necessário se app.py estiver no diretório dashboard
# mas mantém a lógica do template original
# sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
app = Flask(__name__)
app.secret_key = os.urandom(24) # Necessário para flash messages
CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'config.json')
DAYS_OF_WEEK = ["Segunda", "Terça", "Qaurta", "Quinta", "Sexta", "Sabado",
"Domingo"]
def load_config():
 """Carrega a configuração do arquivo JSON."""
 if not os.path.exists(CONFIG_FILE):
 # Cria um config padrão se não existir
 default_config = {
 "schedule": {day: [] for day in DAYS_OF_WEEK},
 "signals_per_session": 3,
 "telegram_token": "",
 "telegram_channel_id": ""
 }
 save_config(default_config)
 return default_config
 try:
 with open(CONFIG_FILE, 'r') as f:
 return json.load(f)
 except (json.JSONDecodeError, IOError) as e:
 flash(f"Erro ao carregar config.json: {e}. Usando configuração padrão.",
"error")
 return {
 "schedule": {day: [] for day in DAYS_OF_WEEK},
 "signals_per_session": 3,
 "telegram_token": "",
 "telegram_channel_id": ""
 }
def save_config(config):
 """Salva a configuração no arquivo JSON."""
 try:
 with open(CONFIG_FILE, 'w') as f:
 json.dump(config, f, indent=2)
 flash("Configuração salva com sucesso!", "success")
 except IOError as e:
 flash(f"Erro ao salvar config.json: {e}", "error")
@app.route('/', methods=['GET', 'POST'])
def index():
 config = load_config()
 if request.method == 'POST':
 new_config = {
 "telegram_token": request.form.get('telegram_token', '').strip(),
 "telegram_channel_id": request.form.get('telegram_channel_id',
'').strip(),
 "signals_per_session": int(request.form.get('signals_per_session', 3)),
 "schedule": {day: [] for day in DAYS_OF_WEEK}
 }
 for day in DAYS_OF_WEEK:
 day_enabled = request.form.get(f'enable_{day.lower()}') == 'on'
 if day_enabled:
 slots_str = request.form.get(f'slots_{day.lower()}', '')
 # Validar e limpar slots (ex: "09:00-10:00, 15:00-16:00")
 valid_slots = []
 for slot in slots_str.split(','):
 slot = slot.strip()
 if slot:
 try:
 start, end = slot.split('-')
 start_h, start_m = map(int, start.split(':'))
 end_h, end_m = map(int, end.split(':'))
 # Validação básica de formato e hora
 if 0 <= start_h <= 23 and 0 <= start_m <= 59 and \
 0 <= end_h <= 23 and 0 <= end_m <= 59 and \
 (start_h < end_h or (start_h == end_h and start_m <
end_m)):

valid_slots.append(f"{start_h:02d}:{start_m:02d}-{end_h:02d}:{end_m:02d}")
 else:
 flash(f"Formato de horário inválido ignorado para
{day}: {slot}", "warning")
 except ValueError:
 flash(f"Formato de horário inválido ignorado para {day}:
{slot}", "warning")
 new_config['schedule'][day] = valid_slots
 save_config(new_config)
 # Recarregar a página para mostrar a mensagem flash e os dados atualizados
 return redirect(url_for('index'))
 # Para o método GET, apenas renderiza o template com a config atual
 return render_template('index.html', config=config, days=DAYS_OF_WEEK)
if __name__ == '__main__':
 # Escuta em todas as interfaces para ser acessível externamente se necessário
 # O modo debug NÃO deve ser usado em produção
 app.run(host='0.0.0.0', port=5000, debug=True)